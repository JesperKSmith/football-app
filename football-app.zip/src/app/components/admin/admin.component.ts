import { Component, OnInit, Input } from '@angular/core';
import { Club } from '../../classes/club';
import { DataService } from '../../services/database/data.service';
import { ActivatedRoute, Router } from '@angular/router';
import {MatButtonModule} from '@angular/material/button';
import { KeysPipe } from  '../keys-pipe/keys-pipe.component';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  
  ngOnInit(): void {
  }

  public club: Club;

  constructor(
    private data: DataService, 
    private route: ActivatedRoute, 
    private router: Router
  ){
    route.params.subscribe( params => {
      let id: number = +params['id'];
      if(id) {
        this.club = Object.assign({}, this.data.getClub(id));
      }
    });
  }

  submitChanges(form) {
    if(form.valid){
      if(this.club.id) { // edit
        this.data.updateClub(this.club);  
      }
      else {
        this.data.createClub(this.club);
      }      
    }
  }

  deleteClub(club) {
    this.data.deleteClub(club);
    
  }

  keys() : Array<string> {
    return Object.keys(this.club);
  }

  values() : Array<string> {
    return Object.values(this.club);
  }

  labelTexts() : Array<string> {
    return ["Matches", "Wins", "Draws", "Losses", "Goals for", "Goals against", "Points"];
  }

}


